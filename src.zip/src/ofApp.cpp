#include "ofApp.h"
#include "Player.hpp"
#include "Ball.hpp"
#include "Opponent.hpp"

string game_state;

void ofApp::setup(){
    ofSetFrameRate(60);
    player = new Player(ofGetWidth() / 16, ofGetHeight() / 2, 0, 10, 80);
    opponent = new Opponent(ofGetWidth() - 100, ofGetHeight() / 2, 0, 10, 80);
    ball = new Ball(ofGetWidth() / 2, ofGetHeight() / 2, 7, ofRandom(1, 5), ofRandom(1, 5));
    game_state = "start";
    
}

void ofApp::update(){
    // Show FPS
    std::stringstream strm;
    strm << "Pong's Revenge | FPS: " << std::floor(ofGetFrameRate() * 1.) / 1.; // No decimals
    ofSetWindowTitle(strm.str());
    
    
    if (game_state == "start") {
    } else if (game_state == "game") {
        player->move();
        opponent->move(ball);
        opponent->bounce();
        ball->bounce(player, opponent);
        
        if (player->outOfZone() == true) {
            player->bounce();
        }
        
    } else if (game_state == "end") {

    }
}

void ofApp::draw(){
    if (game_state == "start") {
        //Start screen setup
        ofImage start_screen;
        start_screen.load("main_menu.png");
        start_screen.draw(0,0);
        //High score
        ofDrawBitmapString("High Score:", 850, 20);
        
    } else if (game_state == "game") {
        player->playerDraw();
        opponent->draw();
        ball->draw();
    } else if (game_state == "end") {

    }
}

void ofApp::keyPressed(int key){
    if (game_state == "game") {
        if (ofGetKeyPressed('w')) {
            player->playerMoveUp();
        }
        if (ofGetKeyPressed('s')) {
            player->playerMoveDown();
        }
    }
}

void ofApp::keyReleased(int key){
    if (game_state == "start") {
        game_state = "game";
    } else if (game_state == "game") {
        // Add later
    }
}

void ofApp::mouseMoved(int x, int y ){

}

void ofApp::mouseDragged(int x, int y, int button){

}

void ofApp::mousePressed(int x, int y, int button){

}

void ofApp::mouseReleased(int x, int y, int button){

}

void ofApp::mouseEntered(int x, int y){

}

void ofApp::mouseExited(int x, int y){

}

void ofApp::windowResized(int w, int h){

}

void ofApp::gotMessage(ofMessage msg){

}

void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
