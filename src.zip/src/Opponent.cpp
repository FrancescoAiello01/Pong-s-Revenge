#include "Opponent.hpp"
#include "Ball.hpp"
#include "ofApp.h"

static const float ACCELERATION = 0.2;

Opponent::Opponent(float x, float y, float v, int w, int h) {
    this->x = x;
    this->y = y;
    this->v = v;
    this->w = w;
    this->h = h;
}

void Opponent::draw() {
    ofSetColor(50, 50, 50);
    ofDrawRectangle(this->x, this->y, this->w, this->h);
}

void Opponent::move(Ball * b) {
//    float ballY = b->getY();
//    y = (ballY - 40);
    
    this->y += this->v;
    
    float tempY = this->y;
    if (tempY + 40 > b->getY()) {
        this->v -= ACCELERATION / 2;
    } else if (tempY + 40 < b->getY()){
        this->v += ACCELERATION / 2;
    } else if (y == b->getY()) {
    }
}

bool Opponent::outOfZone() {
    if (this->y <= 0) {
        this->y = 0;
        return true;
    } else if ((this->y + this->h) >= ofGetHeight()) {
        this->y = ofGetHeight() - this->h;
        return true;
    } else {
        return false;
    }
}

void Opponent::bounce() {
    if (outOfZone()) {
        this->v * -0.9;
    }
}

float Opponent::getOpponentX() {
    return x;
}

float Opponent::getOpponentY() {
    return y;
}
