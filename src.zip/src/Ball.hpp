#ifndef Ball_hpp
#define Ball_hpp

#include <stdio.h>

#endif /* Ball_hpp */

#pragma once
#include "Opponent.hpp"

class Player;

class Ball {
public:
    Ball(float x, float y, float r, float speedX, float speedY);
    void bounce(Player* p, Opponent* o);
    void draw();
    float getY();
    float getX();
private:
    float x;
    float y;
    float r;
    float speedX;
    float speedY;
};
