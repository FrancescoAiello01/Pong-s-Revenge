#include "Ball.hpp"
#include "ofApp.h"
#include "Player.hpp"


Ball::Ball(float x, float y, float r, float speedX, float speedY) {
    this->x = x;
    this->y = y;
    this->r = r;
    this->speedX = speedX;
    this->speedY = speedY;
}

void Ball::bounce(Player * p, Opponent * o) {
    this->x = this->x + speedX;
    this->y = this->y + speedY;
    
    float playerX = p->getPlayerX();
    float playerY = p->getPlayerY();
    
    float opponentX = o->getOpponentX();
    float opponentY = o->getOpponentY();
    
    
    if (this->y > ofGetHeight() - this->r) {
        this->y = ofGetHeight() - this->r;
        speedY *= -1;
    }
    
    
    if (this->x > ofGetWidth() - this->r) {
        this->x = ofGetWidth() - this->r;
        speedX = speedX * -1;
    }
    
    if (this->y < this->r) {
        this->y = this->r;
        speedY = speedY * -1;
    }
    
    if (this->x < this->r) {
        this->x = this->r;
        speedX = speedX * -1;
    }
    
    
    if (playerX < this->x && this->x < (playerX + this->r + 10) && playerY + 80 + this->r > this->y && this->y > playerY - this->r) {
        speedX *= -1;
    }
    
    if (opponentX > this->x && this->x > (opponentX - this->r - 10) && opponentY - 80 - this->r < this->y && this->y < opponentY + this->r) {
        speedX *= -1;
    }

}

void Ball::draw() {
    ofSetColor(50, 50, 50);
    ofDrawCircle(this->x, this->y, this->r);
}

float Ball::getY() {
    return this->y;
}

float Ball::getX() {
    return this->x;
}
